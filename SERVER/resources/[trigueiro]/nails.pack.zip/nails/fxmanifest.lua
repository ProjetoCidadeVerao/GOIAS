-- Generated with AltTool

fx_version 'bodacious'
game { 'gta5' }

files {
  'mp_m_freemode_01_mp_m_nails.meta',
  'mp_f_freemode_01_mp_f_nails.meta'
}

data_file 'SHOP_PED_APPAREL_META_FILE' 'mp_m_freemode_01_mp_m_nails.meta'
data_file 'SHOP_PED_APPAREL_META_FILE' 'mp_f_freemode_01_mp_f_nails.meta'
dependency '/assetpacks'